#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class S2Mirror(Node):
    def __init__(self):
        super().__init__('s2_mirror')
        self.subscription = self.create_subscription(String, '/s1', self.listener_callback, 10)
        self.publisher = self.create_publisher(String, '/s2', 10)
        self.get_logger().info("S2 Mirror started.")

    def listener_callback(self, msg):
        s1_value = msg.data
        s2_value = 'red' if s1_value == 'green' else 'green'
        out_msg = String()
        out_msg.data = s2_value
        self.publisher.publish(out_msg)
        self.get_logger().info(f'Received on /s1: {s1_value} → Publishing on /s2: {s2_value}')

def main(args=None):
    rclpy.init(args=args)
    node = S2Mirror()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

