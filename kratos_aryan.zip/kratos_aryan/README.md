# Week 3 ROS 2 Assignment - Aryan

## Package Name:
`kratos_aryan`



### ✅ Question 1
**Files:**
- `q1_publisher.py`
- `q1_subscriber.py`

Publishes and subscribes to a topic named `/q1_topic`. The publisher sends "Hello World" messages; the subscriber prints them.

---

### ✅ Question 2
**Files:**
- `q2_s1_publisher.py`
- `q2_s2_mirror.py`


S1 publishes a string message to `/mirror_input`, and S2 mirrors the message to `/mirror_output`.

---

### ❌ Question 3
Custom message creation attempted but build failed due to persistent `rosidl_interface_packages` issues. Not included in submission.

---

### ❌ Question 4
Clock system attempted but excluded from final due to build issues. RQT graph unavailable.

---


