#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class S1Publisher(Node):
    def __init__(self):
        super().__init__('s1_publisher')
        self.publisher_ = self.create_publisher(String, '/s1', 10)
        self.timer_period = 10.0
        self.current_state = 'green'
        self.timer = self.create_timer(self.timer_period, self.timer_callback)
        self.get_logger().info("S1 Publisher started.")

    def timer_callback(self):
        msg = String()
        msg.data = self.current_state
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing on /s1: {msg.data}')
        self.current_state = 'red' if self.current_state == 'green' else 'green'

def main(args=None):
    rclpy.init(args=args)
    node = S1Publisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

