import rclpy
from rclpy.node import Node
from kratos_aryan.msg import RoverStatus

class RoverPublisher(Node):
    def __init__(self):
        super().__init__('rover_publisher')
        self.publisher_ = self.create_publisher(RoverStatus, 'rover_status', 10)
        timer_period = 1.0
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.get_logger().info('RoverStatus Publisher Started')

    def timer_callback(self):
        msg = RoverStatus()
        msg.name = "AryanBot"
        msg.battery_level = 87.5
        msg.is_moving = True
        self.publisher_.publish(msg)
        self.get_logger().info(f"Publishing: {msg}")

def main(args=None):
    rclpy.init(args=args)
    node = RoverPublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

